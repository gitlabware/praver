<?php
App::uses('AppModel', 'Model');
/**
 * Producto Model
 *
 */
class Producto extends AppModel {

}
